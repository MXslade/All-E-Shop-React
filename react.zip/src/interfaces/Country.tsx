interface Country {
  id: number,
  name: string,
  code: string
}

export default Country;
