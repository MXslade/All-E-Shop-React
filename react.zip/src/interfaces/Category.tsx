interface Category {
  id: number,
  name: string,
  logoUrl: string
}

export default Category;
