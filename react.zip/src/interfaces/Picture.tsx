interface Picture {
  id: number,
  url: string,
  addedDate: Date
}

export default Picture;
